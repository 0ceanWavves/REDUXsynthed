document.addEventListener("DOMContentLoaded",()=>{setTimeout(()=>{p()},2e3);function p(){document.querySelectorAll(".digital-letter").forEach((t,e)=>{e%2===0&&h(t),(e===2||e===5)&&setInterval(()=>{Math.random()>.7&&l(t)},2e3),t.addEventListener("mouseenter",()=>{t.style.transform="translateY(-3px) scale(1.1)",t.style.filter="brightness(1.3)",l(t)}),t.addEventListener("mouseleave",()=>{t.style.transform="translateY(0) scale(1)",t.style.filter="brightness(1)"})})}function h(o,t){const e=document.createElement("div");e.className="tech-lines-container",e.style.cssText=`
      position: absolute;
      top: -5px;
      left: -5px;
      width: calc(100% + 10px);
      height: calc(100% + 10px);
      pointer-events: none;
      z-index: -1;
    `;const i=2+Math.floor(Math.random()*2);for(let a=0;a<i;a++){const n=document.createElement("div"),s=Math.random()*100,r=Math.random()*100,d=5+Math.random()*15,c=1;n.style.cssText=`
        position: absolute;
        top: ${s}%;
        left: ${r}%;
        width: ${d}px;
        height: ${c}px;
        background: rgba(0, 255, 170, 0.7);
        box-shadow: 0 0 5px rgba(0, 255, 170, 0.7);
        transform: rotate(${Math.random()*360}deg);
        opacity: 0.7;
        pointer-events: none;
      `,e.appendChild(n),n.animate([{opacity:.4,boxShadow:"0 0 3px rgba(0, 255, 170, 0.5)"},{opacity:.8,boxShadow:"0 0 8px rgba(0, 255, 170, 0.8)"},{opacity:.4,boxShadow:"0 0 3px rgba(0, 255, 170, 0.5)"}],{duration:2e3+Math.random()*1e3,iterations:1/0,delay:Math.random()*1e3})}o.style.position="relative",o.appendChild(e)}function l(o){const t=document.createElement("div");t.className="particle-burst",t.style.cssText=`
      position: absolute;
      top: 50%;
      left: 50%;
      width: 0;
      height: 0;
      pointer-events: none;
      z-index: 3;
    `;const e=5+Math.floor(Math.random()*5);for(let i=0;i<e;i++){const a=document.createElement("div"),n=1+Math.random()*2,s=Math.random()*Math.PI*2,r=10+Math.random()*20,d=500+Math.random()*500,c=Math.cos(s)*r,m=Math.sin(s)*r;a.style.cssText=`
        position: absolute;
        top: 0;
        left: 0;
        width: ${n}px;
        height: ${n}px;
        background: rgba(0, 255, 170, 0.9);
        border-radius: 50%;
        box-shadow: 0 0 4px rgba(0, 255, 170, 0.8);
        transform: translate(0, 0);
        opacity: 1;
        pointer-events: none;
      `,t.appendChild(a),a.animate([{transform:"translate(0, 0)",opacity:1},{transform:`translate(${c}px, ${m}px)`,opacity:0}],{duration:d,easing:"cubic-bezier(0.4, 0.0, 0.2, 1)",fill:"forwards"})}o.appendChild(t),setTimeout(()=>{t.remove()},1500)}});
