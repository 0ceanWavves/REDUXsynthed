document.addEventListener("DOMContentLoaded",()=>{const l=document.querySelector(".digital-solutions-text");if(l){l.textContent;let a="";const e="Digital",o=" Solutions";for(let t=0;t<e.length;t++)a+=`<span class="digital-letter" data-index="${t}" style="opacity: 0; transform: translateY(10px);">${e[t]}</span>`;a+=`<span class="solutions-text">${o}</span>`,l.innerHTML=a;const n=document.querySelectorAll(".digital-letter");setTimeout(()=>{n.forEach((t,r)=>{setTimeout(()=>{t.style.transition="opacity 0.3s ease, transform 0.3s ease",t.style.opacity="1",t.style.transform="translateY(0)",c(t),setTimeout(()=>{t.style.transform="translateY(-2px) scale(1.1)",setTimeout(()=>{t.style.transform="translateY(0) scale(1)"},100)},200);const s=document.createElement("div");s.className="letter-flash",s.style.cssText=`
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(ellipse at center, rgba(0, 255, 170, 0.9) 0%, rgba(0, 255, 170, 0) 80%);
            pointer-events: none;
            opacity: 0;
            z-index: 2;
          `,t.style.position="relative",t.appendChild(s),s.animate([{opacity:0},{opacity:.8},{opacity:0}],{duration:400,easing:"ease-out"}),setTimeout(()=>{s.remove()},400)},r*150)})},300);const i=document.querySelector(".solutions-text");i&&(i.style.opacity="1")}function c(a){const e=document.createElement("div"),o=document.createElement("div"),n=`
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: inherit;
      background-clip: text;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-fill-color: transparent;
      pointer-events: none;
    `;e.style.cssText=n+"left: -2px; opacity: 0.8; color: rgba(0, 255, 200, 0.8);",o.style.cssText=n+"left: 2px; opacity: 0.8; color: rgba(255, 0, 255, 0.8);",a.appendChild(e),a.appendChild(o);function i(){if(Math.random()>.95){const r=Math.random()*4-2,s=Math.random()*4-2,d=Math.random()*4-2,p=Math.random()*4-2;e.style.transform=`translate(${r}px, ${s}px)`,o.style.transform=`translate(${d}px, ${p}px)`,e.style.opacity="0.8",o.style.opacity="0.8",setTimeout(()=>{e.style.transform="translate(0, 0)",o.style.transform="translate(0, 0)",e.style.opacity="0",o.style.opacity="0"},50+Math.random()*100)}}const t=setInterval(i,200);a.dataset.glitchInterval=String(t)}});
